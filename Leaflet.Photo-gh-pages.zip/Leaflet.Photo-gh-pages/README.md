Leaflet.Photo
=============

Plugin to show geotagged photos on a Leaflet map. 

[Read this blog post](http://blog.thematicmapping.org/2014/08/showing-geotagged-photos-on-leaflet-map.html)